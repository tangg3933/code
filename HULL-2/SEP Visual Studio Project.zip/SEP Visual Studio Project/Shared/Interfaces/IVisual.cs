﻿using SFML.Graphics;

namespace Shared.Interfaces
{
    public interface IVisual : IAmUpdatable, IAmRenderable
    {

    }
}
