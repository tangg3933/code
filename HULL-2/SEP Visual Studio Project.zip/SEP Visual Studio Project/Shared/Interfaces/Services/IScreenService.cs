﻿using Shared.Core;

namespace Shared.Interfaces.Services
{
    public interface IScreenService
    {
        public void AddChildScreen(Screen screen);
    }
}
