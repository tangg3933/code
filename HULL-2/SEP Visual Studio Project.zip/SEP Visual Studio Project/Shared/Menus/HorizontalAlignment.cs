﻿namespace Shared.Menus
{
    public enum HorizontalAlignment
    {
        Left,
        Centre,
        Right
    }
}
