﻿namespace Shared.Menus
{
    public enum VerticalAlignment
    {
        Top,
        Centre,
        Bottom,
    }
}
