﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shared.Notifications
{
    public enum ToastType
    {
        Info,
        Successful,
        Warning,
        Error
    }
}
