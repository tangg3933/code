﻿namespace Shared.Notifications
{
    public enum ScreenLocation
    {
        TopLeft,
        TopRight,
        BottomLeft,
        BottomRight,
        Centre
    }
}
